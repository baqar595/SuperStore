using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Shop.UI.Pages.Admin
{
    public class ConfigureUsersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}