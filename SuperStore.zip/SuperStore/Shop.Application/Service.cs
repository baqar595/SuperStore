﻿using System;

namespace Shop.Application
{
    public class Service : Attribute { }
}
